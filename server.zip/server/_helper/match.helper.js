const JOBPOSTSMODEL = require("../models/JobPosts");
const CVUPLOADMODEL = require("../models/CV_Upload");
const Profile_MatcherModel = require("../models/profileMatcher");

module.exports = {

  matchCV: async (jobId) => {

    try {
      var searchStartDate = null;
      var searchEndDate = null;
      var whereQuery = {};
      var firstRecord = await CVUPLOADMODEL.find({ sort: { 'createdAt': -1 } }).limit(1);
      var lastRecord = await CVUPLOADMODEL.find({ sort: { 'createdAt': -1 } }).limit(1).skip(100);
      if (firstRecord.length > 0) {
        searchStartDate = firstRecord.updatedAt;
      }
      if (lastRecord.length > 0) {
        searchEndDate = lastRecord.updatedAt;
      }

      var jobPosts = await JOBPOSTSMODEL.findById({ _id: jobId });

      jobPosts.skillCode = jobPosts.skillCode ? jobPosts.skillCode : '';
      var skillRegex = jobPosts.skillCode.replace(/::/g, ":|:");
      var skillArray = skillRegex.replace(/:/g, "").split('|');
      if (skillArray.length == 1 && skillArray[0] == '') {
        skillRegex = '';
        skillArray = [];
      }

      jobPosts.certificationCode = jobPosts.certificationCode ? jobPosts.certificationCode : '';
      var certificationsRegex = jobPosts.certificationCode.replace(/::/g, ":|:");
      var certificationsArray = certificationsRegex.replace(/:/g, "").split('|');
      if (certificationsArray.length == 1 && certificationsArray[0] == '') {
        certificationsRegex = '';
        certificationsArray = [];
      }

      var skillReqCount = skillArray.length;
      var certificatoinReqCount = certificationsArray.length;

      var orCriteria = [];
      if (skillReqCount > 0) {
        orCriteria.push({ skillCode: { $regex: skillRegex } });
      }
      if (certificatoinReqCount > 0) {
        orCriteria.push({ certificationCode: { $regex: certificationsRegex } });
      }
      if (orCriteria.length > 0) {
        whereQuery = {
          $or: orCriteria
        };
      }
      console.log(whereQuery);


      var cvList = [];
      var marcherList = [];

      if (searchStartDate && searchEndDate) {
        whereQuery.updatedAt = { $lte: searchStartDate, $gte: searchEndDate };
      } else if (searchStartDate) {
        whereQuery.updatedAt = { $lte: searchStartDate };
      } else if (searchEndDate) {
        whereQuery.updatedAt = { $gte: searchEndDate };
      }
      cvList = await CVUPLOADMODEL.find(whereQuery).sort({ 'createdAt': -1 });

      var breakCount = 0;
      for (const cvObj of cvList) {

        let matchFieldCount = 0;
        let skillMatchCount = 0;
        let certificationMatchCount = 0;
        let skillScore = 0;
        let certificationScore = 0;
        let applicantScore = 0;
        cvObj.skillCode = cvObj.skillCode ? cvObj.skillCode : '';
        let cvSkillArray = cvObj.skillCode.replace(/::/g, "|").replace(/:/g, "").split('|');
        cvObj.certificationCode = cvObj.certificationCode ? cvObj.certificationCode : '';
        let cvCertificationsArray = cvObj.certificationCode.replace(/::/g, "|").replace(/:/g, "").split('|');

        if (cvSkillArray.length == 1 && cvSkillArray[0] == '') {
          cvSkillArray = [];
        }
        if (cvCertificationsArray.length == 1 && cvCertificationsArray[0] == '') {
          cvCertificationsArray = [];
        }

        if (skillReqCount > 0) {
          matchFieldCount++;
          for (let i = 0; i < skillArray.length; i++) {
            if (cvSkillArray.indexOf(skillArray[i]) > -1) {
              skillMatchCount++;
            }
          }
          skillScore = (skillMatchCount * 100) / skillReqCount;
        }

        if (certificatoinReqCount > 0) {
          matchFieldCount++;
          for (let i = 0; i < certificationsArray.length; i++) {
            if (cvCertificationsArray.indexOf(certificationsArray[i]) > -1) {
              certificationMatchCount++;
            }
          }
          certificationScore = (certificationMatchCount * 100) / certificatoinReqCount;
        }


        applicantScore = (skillScore + certificationScore) / matchFieldCount;

        var matcherObject = {
          "jobId": jobId,
          "applicationId": cvObj._id,
          "score": applicantScore
        };

        console.log(matcherObject);
        console.log(skillArray);
        console.log(cvSkillArray);
        console.log(matchFieldCount, skillMatchCount, certificationMatchCount, skillScore, certificationScore, applicantScore);
        matcherObject = await Profile_MatcherModel.updateOne({ "jobId": jobId, "applicationId": cvObj._id }, { $set: matcherObject }, { upsert: true, new: true });
        marcherList.push(matcherObject);
        if (breakCount++ >= 1) {
          return matcherObject;;
        }
        // return matcherObject;

      }

      var jpbUpdateFields = { $set: { matchStartDate: searchStartDate, matchEndDate: searchEndDate } };
      JOBPOSTSMODEL.updateOne({ _id: jobId }, jpbUpdateFields);

      return { cvList: cvList, marcherList: marcherList };
    } catch (err) {
      console.log("CATCH ::fn[fetchAggregateDatatableRecords]:::>");
      console.error(err);
      return callback(err, null);
    }
  },
  matchJob: async (applicationId) => {

    try {
      var searchStartDate = null;
      var searchEndDate = null;
      var whereQuery = {};
      var firstRecord = await JOBPOSTSMODEL.find({ sort: { 'createdAt': -1 } }).limit(1);
      var lastRecord = await JOBPOSTSMODEL.find({ sort: { 'createdAt': -1 } }).limit(1).skip(100);
      if (firstRecord.length > 0) {
        searchStartDate = firstRecord.updatedAt;
      }
      if (lastRecord.length > 0) {
        searchEndDate = lastRecord.updatedAt;
      }

      var jobPosts = await JOBPOSTSMODEL.findById({ _id: jobId });

      jobPosts.skillCode = jobPosts.skillCode ? jobPosts.skillCode : '';
      var skillRegex = jobPosts.skillCode.replace(/::/g, ":|:");
      var skillArray = skillRegex.replace(/:/g, "").split('|');
      if (skillArray.length == 1 && skillArray[0] == '') {
        skillRegex = '';
        skillArray = [];
      }

      jobPosts.certificationCode = jobPosts.certificationCode ? jobPosts.certificationCode : '';
      var certificationsRegex = jobPosts.certificationCode.replace(/::/g, ":|:");
      var certificationsArray = certificationsRegex.replace(/:/g, "").split('|');
      if (certificationsArray.length == 1 && certificationsArray[0] == '') {
        certificationsRegex = '';
        certificationsArray = [];
      }

      var skillReqCount = skillArray.length;
      var certificatoinReqCount = certificationsArray.length;

      var orCriteria = [];
      if (skillReqCount > 0) {
        orCriteria.push({ skillCode: { $regex: skillRegex } });
      }
      if (certificatoinReqCount > 0) {
        orCriteria.push({ certificationCode: { $regex: certificationsRegex } });
      }
      if (orCriteria.length > 0) {
        whereQuery = {
          $or: orCriteria
        };
      }
      console.log(whereQuery);


      var cvList = [];
      var marcherList = [];

      if (searchStartDate && searchEndDate) {
        whereQuery.updatedAt = { $lte: searchStartDate, $gte: searchEndDate };
      } else if (searchStartDate) {
        whereQuery.updatedAt = { $lte: searchStartDate };
      } else if (searchEndDate) {
        whereQuery.updatedAt = { $gte: searchEndDate };
      }
      cvList = await CVUPLOADMODEL.find(whereQuery).sort({ 'createdAt': -1 });

      var breakCount = 0;
      for (const cvObj of cvList) {

        let matchFieldCount = 0;
        let skillMatchCount = 0;
        let certificationMatchCount = 0;
        let skillScore = 0;
        let certificationScore = 0;
        let applicantScore = 0;
        cvObj.skillCode = cvObj.skillCode ? cvObj.skillCode : '';
        let cvSkillArray = cvObj.skillCode.replace(/::/g, "|").replace(/:/g, "").split('|');
        cvObj.certificationCode = cvObj.certificationCode ? cvObj.certificationCode : '';
        let cvCertificationsArray = cvObj.certificationCode.replace(/::/g, "|").replace(/:/g, "").split('|');

        if (cvSkillArray.length == 1 && cvSkillArray[0] == '') {
          cvSkillArray = [];
        }
        if (cvCertificationsArray.length == 1 && cvCertificationsArray[0] == '') {
          cvCertificationsArray = [];
        }

        if (skillReqCount > 0) {
          matchFieldCount++;
          for (let i = 0; i < skillArray.length; i++) {
            if (cvSkillArray.indexOf(skillArray[i]) > -1) {
              skillMatchCount++;
            }
          }
          skillScore = (skillMatchCount * 100) / skillReqCount;
        }

        if (certificatoinReqCount > 0) {
          matchFieldCount++;
          for (let i = 0; i < certificationsArray.length; i++) {
            if (cvCertificationsArray.indexOf(certificationsArray[i]) > -1) {
              certificationMatchCount++;
            }
          }
          certificationScore = (certificationMatchCount * 100) / certificatoinReqCount;
        }


        applicantScore = (skillScore + certificationScore) / matchFieldCount;

        var matcherObject = {
          "jobId": jobId,
          "applicationId": cvObj._id,
          "score": applicantScore
        };

        console.log(matcherObject);
        console.log(skillArray);
        console.log(cvSkillArray);
        console.log(matchFieldCount, skillMatchCount, certificationMatchCount, skillScore, certificationScore, applicantScore);
        matcherObject = await Profile_MatcherModel.updateOne({ "jobId": jobId, "applicationId": cvObj._id }, { $set: matcherObject }, { upsert: true, new: true });
        marcherList.push(matcherObject);
        if (breakCount++ >= 1) {
          return matcherObject;;
        }
        // return matcherObject;

      }

      var jpbUpdateFields = { $set: { matchStartDate: searchStartDate, matchEndDate: searchEndDate } };
      JOBPOSTSMODEL.updateOne({ _id: jobId }, jpbUpdateFields);

      return { cvList: cvList, marcherList: marcherList };
    } catch (err) {
      console.log("CATCH ::fn[fetchAggregateDatatableRecords]:::>");
      console.error(err);
      return callback(err, null);
    }
  },

  fetchAggregateDatatableRecordsDynamic: async (dtReq, ModelObj, searchFields, aggregatedQuery, projectionQuery, sortingQuery, populateQuery, callback) => {

    var conditionQuery = aggregatedQuery;
    var aggregateQuery = [aggregatedQuery];
    const drawRecord = (dtReq?.draw) || 1;
    const skipRecord = (dtReq?.start) || 0;
    const limitRecord = (dtReq.length) || 50;


    // Aggregate search regex
    try {

      var responseJson = {
        "draw": drawRecord,
        "recordsFiltered": 0,
        "recordsTotal": 0,
        "data": []
      };

      conditionQuery = [conditionQuery];
      conditionQuery.push({ "$group": { _id: null, count: { $sum: 1 } } });

      // for aggregate count [Non - deleted reocrd]
      const totalRecordsCount = await ModelObj.aggregate(conditionQuery);
      console.log("start fetchAggregateDatatableRecordsDynamic: conditionQuery ", conditionQuery, totalRecordsCount);
      responseJson.recordsTotal = (totalRecordsCount && totalRecordsCount[0].count) || 0;
      conditionQuery.pop();
      // for aggregate count [Filter record]
      // aggregateQuery = [aggregateQuery];
      aggregateQuery.push({
        $group: { _id: null, count: { $sum: 1 } }
      });
      console.log("aggregateQuery: ", aggregateQuery);
      const recordsFilteredCount = await ModelObj.aggregate(aggregateQuery);
      console.log("recordsFilteredCount ", recordsFilteredCount);
      if (recordsFilteredCount == 0)
        responseJson.recordsFiltered = 0;
      else
        responseJson.recordsFiltered = (recordsFilteredCount && recordsFilteredCount[0].count) || 0;
      //now remove count stage
      aggregateQuery.pop();

      // For Paginate and Sort
      aggregateQuery.push({
        $skip: Number(skipRecord)
      }, {
        $limit: Number(limitRecord)
      }, {
        $sort: sortingQuery
      });

      console.log("aggregateQuery after POP: ", aggregateQuery);
      var recordsData = await ModelObj.aggregate(aggregateQuery);
      if (recordsData) {
        responseJson.data = recordsData;
        callback(null, responseJson);
      } else {
        let err = new Error(`Error: No record found with query: ${aggregateQuery}`);
        return callback(err, null);
      }
    } catch (err) {
      console.log("CATCH ::fn[fetchAggregateDatatableRecords]:::>");
      console.error(err);
      return callback(err, null);
    }
  },
  fetchDatatableRecords: async (dtReq, ModelObj, fieldNames, conditionQuery, projectionQuery, sortingQuery, populateQuery, callback) => {
    const searchQuery = JSON.parse(JSON.stringify(conditionQuery)) || {};
    const drawRecord = Number(dtReq.draw || 1);
    const skipRecord = Number(dtReq.start || 0);
    const limitRecord = Number(dtReq.length || 50);

    try {
      if (dtReq.search && dtReq.search.value !== "" && fieldNames.length > 0) {
        const regex = new RegExp(dtReq.search.value, "i");
        const orQueryList = [];
        for (let i = 0; i < fieldNames.length; i++) {
          const searchJson = {};
          searchJson[fieldNames[i]] = regex;
          orQueryList.push(searchJson);
        }
        searchQuery.$or = orQueryList;
      }

      const responseJson = {
        draw: drawRecord,
        recordsFiltered: 0,
        recordsTotal: 0,
        data: []
      };

      const totalRecordsCount = await ModelObj.countDocuments(conditionQuery);
      responseJson.recordsTotal = totalRecordsCount;

      let recordsData;
      if (populateQuery && populateQuery.length > 0) {
        recordsData = await ModelObj.find(searchQuery).lean().populate(populateQuery);
        const recordsFilteredCount = (recordsData && recordsData.length) || 0;
        responseJson.recordsFiltered = recordsFilteredCount;
      } else {
        const recordsFilteredCount = await ModelObj.countDocuments(searchQuery);
        responseJson.recordsFiltered = recordsFilteredCount;
      }

      if (populateQuery && populateQuery.length > 0) {
        recordsData = await ModelObj.find(searchQuery).select(projectionQuery).skip(skipRecord).limit(limitRecord).sort(sortingQuery).lean().populate(populateQuery);
      } else {
        recordsData = await ModelObj.find(searchQuery).select(projectionQuery).skip(skipRecord).limit(limitRecord).sort(sortingQuery).lean();
      }

      if (recordsData) {
        responseJson.data = recordsData;
        callback(null, responseJson);
      } else {
        const err = new Error(`Error: No record found with query: ${searchQuery}`);
        callback(err, null);
      }
    } catch (err) {
      console.log("CATCH ::fn[fetchDatatableRecords]:::>");
      console.error(err);
      return callback(err, null);
    }
  }
};

