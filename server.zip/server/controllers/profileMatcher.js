const ProfileMatcherService = require("../services/profileMatcher");
const Profile_MatcherModel = require("../models/profileMatcher");

const matchCVByJobDescriptionId= async (req, res) => {
  try {
    const jobDescriptionId = req.params.jobDescriptionId;
     console.log(jobDescriptionId);
    const findJobMatch = await ProfileMatcherService.getCvMatch(
      jobDescriptionId,
    );
    // console.log(findJobMatch);
    res.status(200).json({
      message: "Match Cv with Job successfully ",
      jobDescriptionId : jobDescriptionId,
      findJobMatch: findJobMatch,
    });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }
};

const matchJobByApplicationId= async (req, res) => {
    try {
      const applicationId = req.params.applicationId;
       console.log(applicationId);
      const findJobMatch = await ProfileMatcherService.getJobMatch(
        applicationId,
      );
      // console.log(findJobMatch);
      res.status(200).json({
        message: "Match Cv with Job successfully ",
        applicationId : applicationId,
        findJobMatch: findJobMatch,
      });
    } catch (err) {
      res.status(500).json({
        message: err.message,
      });
    }
  };

const getMatchList= async (req, res) => {

  try {
    const matchList = await ProfileMatcherService.getMatchList(req, res);
   
    // console.log(findJobMatch);
    res.status(200).json({
      message: "Match List find Successfully",
      applicationId : applicationId,
      matchList: matchList,
    });
  } catch (err) {
    res.status(500).json({
      message: err.message,
    });
  }

  }


module.exports = {
    matchCVByJobDescriptionId,
    matchJobByApplicationId,
    getMatchList,
}; // end of module.exports
